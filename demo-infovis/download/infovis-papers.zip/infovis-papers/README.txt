These 449 papers are extracted from IEEE InfoVis Proceedings from 1995 to 2011,
and prepared by Jason Chuang <jcchuang@cs.washington.edu> for research purposes.
